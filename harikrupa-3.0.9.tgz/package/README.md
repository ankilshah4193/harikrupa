Got it! I see that your original `README.md` had some fantastic details—like the "Architecture & Tech Stack" breakdown, the Node v18 requirement, and the npm badges—that were missing from the previous template.

Here is the fully merged `README.md`. It keeps your original structure and technical depth, but updates the commands (like `--key` instead of `--set-key`) and adds the new frictionless onboarding details (pressing `Enter` to open the browser, and emphasizing the free API key).

```markdown
# 🙏 Harikrupa

**Ancient wisdom dynamically tailored to modern developer burnout.**

[![npm version](https://badge.fury.io/js/harikrupa.svg)](https://www.npmjs.com/package/harikrupa)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Harikrupa is a lightweight, high-performance CLI tool designed to help developers navigate burnout, stress, and life's complex decisions. It utilizes a **Hybrid RAG (Retrieval-Augmented Generation) Architecture**: performing zero-latency semantic search locally, followed by high-speed inference via the Groq API to provide a customized, bilingual response.

---

## 🌟 Core Features

* **Offline-First Vector Search:** Utilizes a local vector database and ONNX runtime to find the most relevant Bhagavad Gita verses instantly, without sending your raw queries to a search engine.
* **Graceful Offline Fallback:** If you lose internet connectivity (e.g., on an airplane), Harikrupa won't crash. It seamlessly switches to Offline Mode, using the local vector search to print the raw Sanskrit and English verse directly to your terminal.
* **Smart Language Detection:** When offline, the CLI intelligently reads the local vector database to see if a pre-compiled translation of your preferred language exists. If not, it gracefully lists the available offline languages.
* **Ultra-Low Latency Inference:** When online, Harikrupa integrates with the Groq API to generate highly contextual responses at blazing speeds.
* **Bilingual Output:** Receive dynamic AI guidance in English alongside your preferred local language (e.g., Gujarati, Hindi, Spanish).

---

## 🚀 Installation

Install the package globally via npm to access the CLI from any terminal:

```bash
npm install -g harikrupa
```

*Note: Requires Node.js v18.0.0 or higher.*

---

## 🛠️ Initial Setup

After installation, run the tool without any flags to launch the interactive setup wizard:

```bash
harikrupa
```

The wizard will guide you through:
1. **Connecting your Groq API key:** You can get a **100% FREE** API key with **no credit card required** from Groq. The CLI will let you just press `Enter` to automatically open the website in your browser!
2. **Setting your preferred language:** Choose the language for your translated wisdom (e.g., Spanish, Gujarati, Hindi).

*(Your API key and preferences are stored securely and locally on your machine at `~/.harikrupa.json`)*

---

## 📖 Usage

Ask any question about life, work, or stress using the `-t` or `--topic` flag:

```bash
harikrupa -t "I am completely burnt out from this release cycle"
```

*(Running `harikrupa` without arguments after setup will display a helpful summary menu of commands and API key information.)*

### Additional Commands

* **Change Language Preference:** ```bash
  harikrupa --lang "Gujarati"
  ```
* **Update API Key Manually:** ```bash
  harikrupa --key "gsk_your_new_api_key_here"
  ```
* **Check Version:** ```bash
  harikrupa --version
  ```
* **Help Menu:** ```bash
  harikrupa --help
  ```

---

## 🏗️ Architecture & Tech Stack

Harikrupa operates in a two-step "relay" to optimize for privacy, speed, and reliability:

### Step 1: Always Local (Semantic Search)
* **Embedding Extraction:** `@xenova/transformers` (`all-MiniLM-L6-v2`) runs entirely on your local machine to convert your query into a mathematical vector.
* **Vector Matching:** Cosine similarity is calculated against a local pre-computed JSON database of verse embeddings to find the perfect matching verse.

### Step 2: The Network Split
* **If Online:** The top-matching verse and your query are sent to **Groq** to generate a highly contextual, structured AI mentor response in your preferred language.
* **If Offline:** The CLI detects the network drop and safely bypasses the AI generation. It dynamically queries the local database for available translations and prints the raw matching verse directly to your terminal.

---

## 📝 License

Distributed under the MIT License. See `LICENSE` for more information.
```