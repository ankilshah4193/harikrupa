#!/usr/bin/env node

import { program } from 'commander';
import chalk from 'chalk';
import fs from 'fs';
import path from 'path';
import os from 'os';
import readline from 'readline';
import dns from 'dns';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import { pipeline, cos_sim } from '@xenova/transformers';
import Groq from 'groq-sdk';

// File System Setup
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, 'data', 'verse_embeddings.json'); 
const CONFIG_PATH = path.join(os.homedir(), '.harikrupa.json');

// Helper for interactive setup
const ask = (question) => {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(chalk.cyan(question), ans => {
    rl.close();
    resolve(ans);
  }));
};

// Helper to open URLs cross-platform
const openBrowser = (url) => {
  const command = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'start' : 'xdg-open';
  exec(`${command} ${url}`, () => {});
};

// Helper to check internet connection
const isOnline = () => {
  return new Promise((resolve) => {
    dns.lookup('google.com', (err) => {
      resolve(!(err && err.code === 'ENOTFOUND'));
    });
  });
};

program
  .version('3.0.9')
  .description('Ancient wisdom for the modern era (English + Preferred Language).')
  .option('-t, --topic <query>', 'Ask your life question in English')
  .option('--lang <language>', 'Change your preferred language preference')
  .option('--key <key>', 'Update your Groq API key manually')
  .action(async (options) => {
    
    // --- 1. LOAD CONFIGURATION ---
    let config = { GROQ_API_KEY: null, PREFERRED_LANGUAGE: null };
    if (fs.existsSync(CONFIG_PATH)) {
      try {
        config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
      } catch (e) {
        config = { GROQ_API_KEY: null, PREFERRED_LANGUAGE: null };
      }
    }

    // --- 2. UPDATE LANGUAGE PREFERENCE ---
    if (options.lang) {
      config.PREFERRED_LANGUAGE = options.lang.trim();
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(config));
      console.log(chalk.green(`\n✅ Language preference updated to: ${config.PREFERRED_LANGUAGE}`));
      console.log(chalk.white("Now run your query to see the change.\n"));
      return;
    }

    // --- 3. SET API KEY MANUALLY & VALIDATE ---
    if (options.key) {
      const newKey = options.key.trim();
      if (!newKey.startsWith('gsk_')) {
        console.log(chalk.red('\n❌ Oops! That does not look like a valid Groq API key.'));
        console.log(chalk.white('Valid keys usually start with "gsk_".'));
        console.log(chalk.white('Please generate a new one at: ') + chalk.blue.underline('https://console.groq.com/keys'));
        console.log(chalk.white('Once you have it, try running this command again:'));
        console.log(chalk.cyan('harikrupa --key "your_new_key_here"\n'));
        return;
      }
      config.GROQ_API_KEY = newKey;
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(config));
      console.log(chalk.green(`\n✅ API Key updated successfully.\n`));
      return;
    }

    // --- 4. ONBOARDING WIZARD ---
    if (!config.GROQ_API_KEY || !config.PREFERRED_LANGUAGE) {
      console.log(chalk.green.bold("\n🌟 Welcome to Harikrupa Setup Wizard"));
      console.log(chalk.white("Let's get you connected to the Gita in 2 quick steps.\n"));

      if (!config.GROQ_API_KEY) {
        console.log(chalk.yellow.bold("Step 1: Get your FREE API key from Groq (No credit card required!)"));
        
        let userKey = await ask("Press ENTER to open the website, or paste your API key here if you have it: ");
        
        if (userKey.trim() === '') {
          console.log(chalk.white.dim("\nOpening https://console.groq.com/keys in your browser..."));
          openBrowser('https://console.groq.com/keys');
          userKey = await ask(chalk.cyan("Once you've copied your key (starts with 'gsk_'), paste it here: "));
        }
        
        const cleanKey = userKey.trim();
        
        // Friendly rejection if they mess up the wizard input
        if (!cleanKey.startsWith('gsk_')) {
          console.log(chalk.red('\n❌ Oops! The API key you entered seems invalid (it should start with "gsk_").'));
          console.log(chalk.white('Don\'t worry! You can generate a new one for free at https://console.groq.com/keys'));
          console.log(chalk.white('Once you have it, just run this command to save it and skip setup:'));
          console.log(chalk.cyan('harikrupa --key "your_new_key_here"\n'));
          return; // Exit out safely so they aren't stuck
        }
        
        config.GROQ_API_KEY = cleanKey;
      }

      if (!config.PREFERRED_LANGUAGE) {
        console.log(""); // Spacing
        const userLang = await ask("Step 2: What is your preferred language for the answers? (e.g., Gujarati, Hindi, Spanish): ");
        config.PREFERRED_LANGUAGE = userLang.trim() || 'English';
      }

      fs.writeFileSync(CONFIG_PATH, JSON.stringify(config));
      console.log(chalk.green("\n✅ Setup Complete! All settings saved."));
      console.log(chalk.white("Now try: ") + chalk.cyan('harikrupa -t "I feel overwhelmed"') + "\n");
      return;
    }

    // --- 5. INPUT VALIDATION & HELP MENU ---
    if (!options.topic) {
      console.log(chalk.yellow.bold('\n🕉️  Harikrupa - Ancient wisdom for the modern era'));
      console.log(chalk.white('\nUsage: ') + chalk.cyan('harikrupa -t "Your question here"'));
      console.log(chalk.white.dim('Example: harikrupa -t "I feel anxious about my career"'));
      
      console.log(chalk.white('\n⚙️  Settings:'));
      console.log(chalk.white('  harikrupa --lang "Spanish"  ') + chalk.white.dim('-> Change output language'));
      console.log(chalk.white('  harikrupa --key "gsk_"      ') + chalk.white.dim('-> Update your API key'));
      
      console.log(chalk.cyan.bold('\n🔑 API Key Info:'));
      console.log(chalk.white('Harikrupa uses Groq for lightning-fast AI translations.'));
      console.log(chalk.white('You can get a ') + chalk.green.bold('100% FREE') + chalk.white(' API key with ') + chalk.yellow.bold('no credit card required') + chalk.white('.'));
      console.log(chalk.white('Get it here: ') + chalk.blue.underline('https://console.groq.com/keys\n'));
      return;
    }

    const prefLang = config.PREFERRED_LANGUAGE || 'English';

    console.log(chalk.blue(`\nReflecting on your situation in English & ${prefLang}...\n`));

    try {
      // --- 6. LOCAL SEMANTIC SEARCH ---
      if (!fs.existsSync(DB_PATH)) {
        throw new Error("Local database missing. Ensure 'data/verse_embeddings.json' exists.");
      }

      const extractor = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
      const queryOutput = await extractor(options.topic, { pooling: 'mean', normalize: true });
      const queryVector = queryOutput.tolist()[0];

      const verses = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));

      let bestMatch = null;
      let highestScore = -1;

      for (const verse of verses) {
        const score = cos_sim(queryVector, verse.embedding);
        if (score > highestScore) {
          highestScore = score;
          bestMatch = verse;
        }
      }

      const MIN_THRESHOLD = 0.25; 
      if (highestScore < MIN_THRESHOLD) {
        bestMatch = verses.find(v => String(v.chapter) === "18" && String(v.verse) === "66") || verses[0];
      }

      if (!bestMatch) throw new Error("Could not find a relevant verse.");

      const gold = chalk.hex('#FFD700').bold; 
      const subTitleColor = chalk.cyanBright.bold;
      const bodyText = chalk.white.dim;

      // --- OFFLINE FALLBACK CHECK ---
      const online = await isOnline();
      if (!online) {
        console.log(chalk.yellow('⚠️  No Internet Connection Detected.'));
        console.log(bodyText('Harikrupa is running in Offline Mode. AI mentor commentary is disabled, but here is your guiding verse:\n'));
        
        console.log(gold(`Wisdom from Srimad Bhagavad Gita: Chapter ${bestMatch.chapter}, Verse ${bestMatch.verse}`));
        console.log(chalk.white("--------------------------------------------------"));
        console.log(subTitleColor("Sanskrit:"));
        console.log(bodyText(bestMatch.sanskrit_verse));
        
        const localLangKey = prefLang.toLowerCase();
        const excludedKeys = ['chapter', 'verse', 'sanskrit_verse', 'embedding'];
        const availableLangs = Object.keys(bestMatch)
            .filter(key => !excludedKeys.includes(key))
            .map(lang => lang.charAt(0).toUpperCase() + lang.slice(1));

        if (localLangKey !== 'english') {
            console.log(subTitleColor(`\n${prefLang}:`));
            if (bestMatch[localLangKey]) {
                console.log(bodyText(bestMatch[localLangKey]));
            } else {
                console.log(chalk.yellow(`⚠️ Offline Translation Unavailable`));
                console.log(bodyText(`Your local database currently only has pre-downloaded translations for: ${availableLangs.join(', ')}.`));
                console.log(bodyText(`(Please connect to the internet so the AI can dynamically translate this into ${prefLang})`));
            }
        }

        console.log(subTitleColor("\nEnglish:"));
        console.log(bodyText(bestMatch.english));
        console.log(chalk.white("--------------------------------------------------\n"));
        return; 
      }

      // --- 7. GROQ BILINGUAL MENTOR PROMPT ---
      const groq = new Groq({ apiKey: config.GROQ_API_KEY });
      
      const systemPrompt = `
      You are a wise mentor and Bhagavad Gita expert.

      User Input: "${options.topic}"
      Most Relevant Verse: Chapter ${bestMatch.chapter}, Verse ${bestMatch.verse}
      Sanskrit Original: ${bestMatch.sanskrit_verse}

      YOUR TASK:
      Divide your response into two exact sections: "### English Perspective" and "### ${prefLang} Perspective". 

      Under "### English Perspective":
      **Sanskrit Verse:** [Provide original Sanskrit]
      **Transliteration (IAST):** [Provide phonetic text]
      **Translation (English):** [Provide ONLY the English translation]
      **Empathy:** [Acknowledge their situation in 1-2 lines]
      **Connection:** [Explain the cosmic narrative from the Gita in 1-2 lines]
      **Practical Wisdom:** [Provide a modern mental hack or vibe shift in 1-2 lines]
      **Next Action:** [Provide a high-energy practical step in 1-2 lines]

      Under "### ${prefLang} Perspective":
      Translate ALL the subheaders themselves into ${prefLang} (e.g., **Verso en Sánscrito:**, **Empatía:**, etc.).
      1. Provide the Sanskrit under the translated Sanskrit subheader.
      2. Provide the Transliteration under the translated Transliteration subheader.
      3. Provide ONLY the ${prefLang} translation of the verse under the translated Translation subheader.
      4. Provide the fully translated commentary sections under their respective translated subheaders.

      STRICT RULES:
      - Do not cross translations (no English verse translation in the ${prefLang} section, and vice versa).
      - Ensure EVERY subheader is wrapped in double asterisks like **This**.
      - DO NOT use em-dashes (—) anywhere in your response. Use commas, colons, or periods instead.
      - Keep the language simple and avoid complex vocabulary.
      `;

      const chatCompletion = await groq.chat.completions.create({
        messages: [{ role: 'system', content: systemPrompt }],
        model: 'openai/gpt-oss-120b', 
        temperature: 0.5,
      });

      // --- 8. FINAL OUTPUT ---
      console.log(gold(`Wisdom from Srimad Bhagavad Gita: Chapter ${bestMatch.chapter}, Verse ${bestMatch.verse}`));
      console.log(chalk.white("--------------------------------------------------\n"));
      
      let rawResponse = chatCompletion.choices[0]?.message?.content || "";

      let coloredResponse = rawResponse.split('\n').map(line => {
        if (line.match(/^###\s+/)) {
          return gold(line);
        }
        
        if (line.trim() === '') {
          return line;
        }

        if (line.match(/\*\*(.*?)\*\*/)) {
          let parts = line.split(/(\*\*.*?\*\*)/g);
          return parts.map(part => {
            if (part.startsWith('**') && part.endsWith('**')) {
              const cleanText = part.replace(/\*\*/g, '');
              return subTitleColor(cleanText); 
            } else if (part.trim() !== '') {
              return bodyText(part); 
            }
            return part;
          }).join('');
        }
        
        return bodyText(line);
      }).join('\n');

      console.log(coloredResponse);
      
      console.log(chalk.white("\n--------------------------------------------------\n"));

    } catch (error) {
      console.log(chalk.red('\n❌ System Error:'));
      console.error(chalk.white(error.message));
      
      // Handle Authentication / Invalid Key Errors gracefully at runtime
      if (error.message.includes('401') || error.message.includes('invalid') || error.message.includes('API key')) {
        console.log(chalk.yellow("\n⚠️  It looks like your current Groq API key is invalid or expired."));
        console.log(chalk.white("You can easily generate a new, free key at: ") + chalk.blue.underline("https://console.groq.com/keys"));
        console.log(chalk.white("Then, update it in Harikrupa by running:"));
        console.log(chalk.cyan('harikrupa --key "your_new_key_here"\n'));
      } else if (error.message.includes('fetch') || error.message.includes('network')) {
        console.log(chalk.yellow("\nTip: Check your internet connection. We need it to talk to Groq."));
      }
    }
  });

program.parse(process.argv);